package calculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class calci {

	private JFrame frame;
	private JButton B;
	private JButton btn9;
	private JButton btn6;
	private JButton btn1;
	private JButton zero;
	private JButton btnC;
	private JButton btn8;
	private JButton btn5;
	private JButton btn2;
	private JButton btndot;
	private JButton btn00;
	private JButton btn7;
	private JButton btn4;
	private JButton btnThree;
	private JButton btnequal;
	private JButton btnsum;
	private JButton btnminus;
	private JButton btnmultip;
	private JButton divide;
	private JButton percent;
	private JTextField textField;
	double first;
	double second;
	double result;
	String operation;
	String answer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calci window = new calci();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calci() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 323, 435);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		B = new JButton("\uF0E7");
		B.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String backSpace=null;
				if(textField.getText().length()>0) {
					StringBuilder str=new StringBuilder(textField.getText());
					str.deleteCharAt(textField.getText().length()-1);
					backSpace=str.toString();
					textField.setText(backSpace);
					
				}
			}
		});
		B.setBounds(36, 109, 61, 48);
		frame.getContentPane().add(B);
		
		btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn9.getText();
				textField.setText(number);
			}
		});
		btn9.setBounds(36, 157, 61, 48);
		frame.getContentPane().add(btn9);
		
		btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn6.getText();
				textField.setText(number);
			}
		});
		btn6.setBounds(36, 205, 61, 48);
		frame.getContentPane().add(btn6);
		
		btn1 = new JButton("1");
		btn1.setBounds(36, 254, 61, 48);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn1.getText();
				textField.setText(number);
			}
		});
		frame.getContentPane().add(btn1);
		
		zero = new JButton("0");
		zero.setBounds(36, 299, 61, 48);
		frame.getContentPane().add(zero);
		
		btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
			}
		});
		btnC.setBounds(97, 109, 61, 48);
		frame.getContentPane().add(btnC);
		
		btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn8.getText();
				textField.setText(number);
			}
		});
		btn8.setBounds(97, 157, 61, 48);
		frame.getContentPane().add(btn8);
		
		btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn5.getText();
				textField.setText(number);
			}
		});
		btn5.setBounds(97, 205, 61, 48);
		frame.getContentPane().add(btn5);
		
		btn2 = new JButton("2");
		btn2.setBounds(97, 254, 61, 48);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn2.getText();
				textField.setText(number);
			}
		});
		frame.getContentPane().add(btn2);
		
		btndot = new JButton(".");
		btndot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btndot.getText();
				textField.setText(number);
			}
		});
		btndot.setBounds(97, 299, 61, 48);
		frame.getContentPane().add(btndot);
		
		btn00 = new JButton("00");
		btn00.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn00.getText();
				textField.setText(number);
			}
		});
		btn00.setBounds(157, 109, 61, 48);
		frame.getContentPane().add(btn00);
		
		btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn7.getText();
				textField.setText(number);
			}
		});
		btn7.setBounds(157, 157, 61, 48);
		frame.getContentPane().add(btn7);
		
		btn4 = new JButton("4");
		btn4.setBounds(157, 205, 61, 48);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btn4.getText();
				textField.setText(number);
			}
		});
		frame.getContentPane().add(btn4);
		
		btnThree = new JButton("3");
		btnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number=textField.getText()+btnThree.getText();
				textField.setText(number);
			}
		});
		btnThree.setBounds(157, 254, 61, 48);
		frame.getContentPane().add(btnThree);
		
		btnequal = new JButton("=");
		btnequal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			String answer;
			second=Double.parseDouble(textField.getText());
			if(operation=="+")
			{
				result=first+second;
				answer=String.format("%.2f", result);
				textField.setText(answer);
				
			}
			else	if(operation=="-")
			{
				result=first-second;
				answer=String.format("%.2f", result);
				textField.setText(answer);
				
			}
			else if(operation=="*")
			{
				result=first*second;
				answer=String.format("%.2f", result);
				textField.setText(answer);
				
			}
			if(operation=="/")
			{
				result=first/second;
				answer=String.format("%.2f", result);
				textField.setText(answer);
				
			}
				
			if(operation=="%")
			{
				result=first%second;
				answer=String.format("%.2f", result);
				textField.setText(answer);
				
			}
				
				
				
				
				
				
				
				
				
				
			}
		});
		btnequal.setBounds(157, 299, 61, 48);
		frame.getContentPane().add(btnequal);
		
		btnsum = new JButton("+");
		btnsum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation="+";
			}
		});
		btnsum.setBounds(219, 109, 61, 48);
		frame.getContentPane().add(btnsum);
		
		btnminus = new JButton("-");
		btnminus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation="-";
			}
		});
		btnminus.setBounds(219, 157, 61, 48);
		frame.getContentPane().add(btnminus);
		
		btnmultip = new JButton("*");
		btnmultip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation="*";
			}
		});
		btnmultip.setBounds(219, 205, 61, 48);
		frame.getContentPane().add(btnmultip);
		
		divide = new JButton("/");
		divide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation="/";
			}
		});
		divide.setBounds(219, 254, 61, 48);
		frame.getContentPane().add(divide);
		
		percent = new JButton("%");
		percent.setBounds(219, 299, 61, 48);
		percent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(textField.getText());
				textField.setText("");
				operation="%";
			}
		});
		frame.getContentPane().add(percent);
		
		textField = new JTextField();
		textField.setBounds(10, 11, 287, 87);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
	}
}
