/**
 * 
 */
/**
 * @author Vishakha
 *
 */
module calculator {
	requires java.desktop;
}